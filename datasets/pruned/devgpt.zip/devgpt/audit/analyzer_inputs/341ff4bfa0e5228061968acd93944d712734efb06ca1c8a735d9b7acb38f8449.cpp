void fHMM::run() {
}