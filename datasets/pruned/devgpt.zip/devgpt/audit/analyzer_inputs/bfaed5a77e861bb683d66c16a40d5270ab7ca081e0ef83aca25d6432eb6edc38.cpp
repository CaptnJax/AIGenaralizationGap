void loop() {
  myDevice.handleInterrupt();
}