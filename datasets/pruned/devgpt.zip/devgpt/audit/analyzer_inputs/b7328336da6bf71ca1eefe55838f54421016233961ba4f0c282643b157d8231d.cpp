void setup() {
  Serial.begin(115200);
  myDevice.begin();
}