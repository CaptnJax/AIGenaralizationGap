void draw_vector(std::ofstream &svgFile, Point2D &tail, Point2D &head, const std::string &stroke_color) {
    svgFile << "<line x1=\"" << head.x << "\" x2=\"" << tail.x << "\" y1=\"" << head.y << "\" y2=\"" << tail.y << "\" stroke=\"" << stroke_color << "\" stroke-width=\"5\" marker-start=\"url(#Arrow1Sstart)\" />" << std::endl;
}