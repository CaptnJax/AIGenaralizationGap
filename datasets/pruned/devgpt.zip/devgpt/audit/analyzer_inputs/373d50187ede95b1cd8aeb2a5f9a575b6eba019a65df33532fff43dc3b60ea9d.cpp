void fillArrayWithMultiplesOfFive(int array[], int size) {
    for (int i = 0; i < size; ++i) {
        array[i] = i * 5;
    }
}